package com.cg.billing.client;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingSevicesImpl;
public class MainClass {
	public static void main(String[] args) {
		BillingServices services=new BillingSevicesImpl();
		int customerId=services.acceptCustomerDetails("Sayan", "Datta", "sayan26datta@gmail.com", "23/01/96", "Rishra", "WestBengal", 712248, "Rishra", "WestBengal", 712248);
		System.out.println("Customer Id :"+customerId);
	try {
		long plan=services.openPostpaidMobileAccount(1, 50);
		System.out.println("plan :"+plan);
	} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException e) {		
		e.printStackTrace();
	}	
	}	
}