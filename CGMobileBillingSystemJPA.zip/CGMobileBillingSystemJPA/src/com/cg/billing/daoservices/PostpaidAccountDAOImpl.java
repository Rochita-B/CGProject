package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;

public class PostpaidAccountDAOImpl implements PostpaidAccountDAO{
	 private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public PostpaidAccount save(PostpaidAccount account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
		
	}

	@Override
	public boolean update(PostpaidAccount account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	

	@Override
	public PostpaidAccount findOne(long mobileNo) {
		return entityManagerFactory.createEntityManager().find(PostpaidAccount.class, mobileNo);
	}

	@Override
	public List<PostpaidAccount> findAll() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createNamedQuery("from PostPaidAccout a",PostpaidAccount.class);
		return query.getResultList();
	}

	@Override
	public boolean delete(PostpaidAccount account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.remove(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

}
