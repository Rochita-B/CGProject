package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingController {

	@Autowired
	BankingServices bankingServices;

	@RequestMapping("/registerAccount")
	public ModelAndView registerAccount(@ModelAttribute Account account) throws AccountNotFoundException, BankingServicesDownException {
		account=bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage","account",account);
	}

	@RequestMapping("/AccountDetails")
	public ModelAndView getAccountDetails(@RequestParam long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("findAccountDetails","account",account);
	}
	@RequestMapping("/DepositionDetails")
	public ModelAndView getDepositionDetails(@RequestParam long accountNo,long amount) throws AccountNotFoundException, 
	BankingServicesDownException, AccountBlockedException {
		float account=bankingServices.depositAmount(accountNo, amount);
		System.out.println(account);
		return new ModelAndView("depositionSuccessfulPage","account",account);
	}
	@RequestMapping("/WithdrawDetails")
	public ModelAndView getWithdrawDetails(@RequestParam long accountNo,long amount) throws AccountNotFoundException, 
	BankingServicesDownException, AccountBlockedException {
		float account=bankingServices.withdrawAmount(accountNo, amount);
		System.out.println(account);
		return new ModelAndView("withdrawalSuccessfulPage","account",account);
	}
	@RequestMapping("/TransferDetails")
	public ModelAndView getTransferDetails(@RequestParam long accountNoFrom,long accountNoTo,long transferAmount,int pinNumber) throws AccountNotFoundException, 
	BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		boolean account=bankingServices.fundTransfer(accountNoFrom, accountNoTo, transferAmount, pinNumber);
		System.out.println(account);
		return new ModelAndView("transferSuccessfulPage","account",account);
	}
}
