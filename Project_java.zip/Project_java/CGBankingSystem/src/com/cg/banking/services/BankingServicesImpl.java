package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exception.AccountBlockedException;
import com.cg.banking.exception.AccountNotFoundException;
import com.cg.banking.exception.BankingServicesDownException;
import com.cg.banking.exception.InsufficientAmountException;
import com.cg.banking.exception.InvalidAccountTypeException;
import com.cg.banking.exception.InvalidAmountException;
import com.cg.banking.exception.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

public class BankingServicesImpl implements BankingServices {
	AccountDAOImpl accounts=new 	AccountDAOImpl();
	private final static float minBal=1000;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAccountTypeException, InvalidAmountException, BankingServicesDownException {
		if(minBal<1000) throw new InvalidAmountException();
		return accounts.save(new Account(accountType,initBalance));
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=accounts.findOne(accountNo);
		if(customers==null) throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("blocked"))
			throw new AccountBlockedException();
		else
			customers.setAccountBalance(customers.getAccountBalance() +amount);
		return customers.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, AccountBlockedException {
		Account customers=null;
		customers=accounts.findOne(accountNo);
		if(customers==null) throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("blocked"))
			throw new AccountBlockedException();
		else if(customers.getPinNumber()!=pinNumber) throw new InvalidPinNumberException();
		else if(customers.getAccountBalance()-amount<=minBal) throw new InsufficientAmountException();
		else
			customers.setAccountBalance(customers.getAccountBalance() -amount);
		return customers.getAccountBalance();		
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account custTo=null;
		Account custFrom=null;
		custTo=accounts.findOne(accountNoTo);
		custFrom=accounts.findOne(accountNoFrom);
		if(custFrom.getPinNumber()!=pinNumber) throw new InvalidPinNumberException();
		else {
			custFrom.setAccountBalance(withdrawAmount(custFrom.getAccountNumber(), transferAmount, custFrom.getPinNumber()));
		custTo.setAccountBalance(depositAmount(custTo.getAccountNumber(), transferAmount));
		}
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		return null;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account>customers=accounts.findAll();
		return customers;
	}

	@Override
	public List<Transaction> getAccountAllTransactions(long AccountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customers=accounts.findOne(accountNo);
		if(customers==null) throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("blocked"))
			throw new AccountBlockedException();
		return customers.getAccountStatus();
	}
	@Override
	public String getAccountBalance(long accountNo) {
		return null;
	}

}
