package com.cg.payroll.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private AssociateDAO associateDAO;

	
	
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		double a = associate.getSalary().getBasicSalary() - (250000 + associate.getYearlyInvestmentUnder8oC()
		+ associate.getSalary().getCompanyPf() + associate.getSalary().getEpf());
		double b = a - 500000;
		double c = b - 1000000;
		double netSalary;
		if (associate.getSalary().getBasicSalary() <= 250000) {
			netSalary = associate.getSalary().getBasicSalary();
			return  (int) netSalary;
		} else if (associate.getSalary().getBasicSalary() <= 500000
				&& associate.getSalary().getBasicSalary() > 250000) {
			netSalary = associate.getSalary().getBasicSalary() - (a * 0.1);
			return  (int) netSalary;
		} else if (associate.getSalary().getBasicSalary() <= 1000000
				&& associate.getSalary().getBasicSalary() > 500000) {
			netSalary = associate.getSalary().getBasicSalary() - ((a * 0.1) + b * 0.2);
			return  (int) netSalary;
		} else {
			netSalary = associate.getSalary().getCompanyPf() - ((a * 0.1) + (b * 0.2) + (c * 0.3));
			return  (int) netSalary;
		}
	}

	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
	return  associateDAO.findById(associateId).orElseThrow(()-> 
			new AssociateDetailsNotFoundException("associate details not found for this associate id"));
		
	}

	@Override
	public List<Associate> getAllAssociatesDetails() {

		return  associateDAO.findAll();
	}

	@Override
	public double calculateGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		return (associate.getSalary().getBasicSalary() + 0.3 * associate.getSalary().getBasicSalary() * 2
				+ 0.25 * associate.getSalary().getBasicSalary() + associate.getSalary().getCompanyPf()
				+ associate.getSalary().getEpf());

	}

	

	@Override
	public Associate acceptAssociateDetails(Associate associate) {
		return associateDAO.save(associate);
	}

	@Override
	public int acceptAssociateDetails(int id, String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		// TODO Auto-generated method stub
		return 0;
	}





}
