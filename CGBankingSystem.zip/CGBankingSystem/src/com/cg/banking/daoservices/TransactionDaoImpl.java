package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDaoImpl implements TransactionDAO{

	@Override
	public Transaction save(long accountNo,Transaction transaction) {
         transaction.setTransactionId(BankingDBUtil.generateTRANSACTION_ID());
         BankingDBUtil.accounts.get(accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
         return transaction;
		}

	@Override
	public boolean update(Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Transaction findOne(long accNo,int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAll(long accountNo) {
		// TODO Auto-generated method stub
		return new ArrayList<Transaction>(BankingDBUtil.accounts.get(accountNo).getTransactions().values());
	}

	@Override
	public Transaction save(Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction findOne(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
