package com.cg.banking.util;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exception.AccountBlockedException;
import com.cg.banking.exception.AccountNotFoundException;
import com.cg.banking.exception.BankingServicesDownException;
import com.cg.banking.exception.InsufficientAmountException;
import com.cg.banking.exception.InvalidAccountTypeException;
import com.cg.banking.exception.InvalidAmountException;
import com.cg.banking.exception.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

public class MainClass {

	public static void main(String[] args) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		long accNo;
		int pinNo;
		float amount;
		BankingServices services=new BankingServicesImpl();
		Account customer1=null;
		Account customer2=null;
		try {
			customer1=services.openAccount("Savings", 2000);
			customer1.setAccountStatus("active");
			System.out.println(customer1.getAccountBalance());
		}
		catch(InvalidAmountException|InvalidAccountTypeException|BankingServicesDownException e) {
			e.printStackTrace();
		}
		try {
			customer2=services.openAccount("current", 3000);
			customer2.setAccountStatus("active");
		}
		catch(InvalidAmountException|InvalidAccountTypeException|BankingServicesDownException e) {
			e.printStackTrace();
		}
		System.out.println("Account Details : "+customer1);
		System.out.println("Account Details : "+customer2);

		Scanner sc=new Scanner(System.in);

		System.out.println("-------WITHDRAWAL-------------------");
		System.out.println("enter account number: ");
		accNo=sc.nextLong();

		System.out.println("enter the pin number: ");
		pinNo=sc.nextInt();
		System.out.println("enter the amount to be withdrawn :");
		amount=sc.nextFloat();
		try {
			System.out.println(services.withdrawAmount(accNo,amount,pinNo));
			System.out.println("account details after withdrawal: "+services.getAccountDetails(accNo));
		}
		catch(InsufficientAmountException|AccountNotFoundException|InvalidPinNumberException|BankingServicesDownException|AccountBlockedException e) {
			e.printStackTrace();

		}
		System.out.println("-------DEPOSIT-------------------");
		System.out.println("enter account number: ");
		accNo=sc.nextLong();
		System.out.println("enter the pin number: ");
		pinNo=sc.nextInt();
		try {
			System.out.println(services.depositAmount(accNo,amount));
			System.out.println("account details after deposition: "+services.getAccountDetails(accNo));
		}
		catch(AccountNotFoundException|BankingServicesDownException|AccountBlockedException e) {
			e.printStackTrace();

		}
		System.out.println("----------------FUND TRANSFER-------------------");
		System.out.println("enter account numberTo: ");
		long accNo1 = sc.nextLong();
		System.out.println("enter account numberFrom: ");
		long accNo2 = sc.nextLong();
		System.out.println("enter the amount to be transfered: ");
		float amount1=sc.nextFloat();
		System.out.println("enter the pin number of accountTo: ");
		pinNo=sc.nextInt();
		try {
			System.out.println(services.fundTransfer(accNo,  accNo2,  amount1,  pinNo));		
		} catch (InsufficientAmountException e) {
			e.printStackTrace();
		} catch (InvalidPinNumberException e) {
			e.printStackTrace();
		}
	}

}
