package com.cg.banking.util;
import java.util.HashMap;
import com.cg.banking.beans.Account;
public class BankingDBUtil {
	public static HashMap<Long, Account> accounts=new HashMap<>();
		private static long ACCOUNT_NUMBER=1000;
		public static long getACCOUNT_NUMBER() {
			return ++ACCOUNT_NUMBER;
		}
		public static int generateTRANSACTION_ID() {
			// TODO Auto-generated method stub
			return 0;
		}
	}


