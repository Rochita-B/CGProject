package com.cg.banking.client;
import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args) throws InsufficientAmountException, InvalidPinNumberException {
		long accNo;
		long pinNo;
		float amt;
		Scanner sc = new Scanner(System.in);
		BankingServices services = new BankingServicesImpl();
		Account customer1 = null;
		Account customer2 = null;
		try {
			customer1 = services.openAccount("Savings", 10000);
			customer1.setAccountStatus("Active");
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			e.printStackTrace();
		}
		try {
			customer2 = services.openAccount("Salary", 5000);
			customer2.setAccountStatus("Active");
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			e.printStackTrace();
		}
		System.out.println("Customer Details: " + customer1);
		System.out.println("Customer Details: " + customer2);
		while(true) {
		System.out.println("\n\t\tOPERATION CHOICES\n");
		System.out.println("1.Withdraw Amount\n2.Deposit Amount\n3.Fund Transfer\n4.Exit");
		System.out.println("Enter your choice:");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("\n\t\tWITHDRAWL OPERATION\n");
			System.out.println("Enter Account Number:");
			accNo = sc.nextLong();
			System.out.println("Enter Pin No.: ");
			pinNo = sc.nextLong();
			System.out.println("Enter Amount to Withdraw:");
			amt = sc.nextFloat();
			try {
				System.out.println(services.withdrawAmount(accNo, amt, pinNo));
				System.out.println("Account Details After Withdrawl:" + services.getAccountDetails(accNo));
			} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
				e.printStackTrace();
			} catch (InsufficientAmountException e) {
				e.printStackTrace();
			} catch (InvalidPinNumberException e) {
				e.printStackTrace();
			}
			System.out.println("--------------------------------------------------");
			break;			
		case 2:
			System.out.println("\n\t\tDEPOSIT OPERATION\n");
			System.out.println("Enter Account Number:");
			accNo = sc.nextLong();
			System.out.println("Enter Amount to Deposit:");
			amt = sc.nextFloat();
			try {
				System.out.println(services.depositAmount(accNo, amt));
				System.out.println("Account Details After Deposit:" + services.getAccountDetails(accNo));
			} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
				e.printStackTrace();
			}
			System.out.println("--------------------------------------------------");
			break;
		case 3:
			System.out.println("\n\t\tFUND TRANSFER OPERATION\n");
			System.out.println("Enter Account Number to transfer from:");
			Long accountNoTo = sc.nextLong();
			System.out.println("Enter Account Number to transfer to:");
			Long accountNoFrom = sc.nextLong();
			System.out.println("Enter Amount to transfer:");
			Float transferAmount = sc.nextFloat();
			System.out.println("Enter Pin No.: ");
			long pinNumber = sc.nextLong();
			try {
				System.out.println(services.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber));
				System.out.println("Account Details After Fund Transfer:" + services.getAccountDetails(accountNoFrom));
			} catch (InsufficientAmountException|InvalidPinNumberException|AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
				e.printStackTrace();
			}
			System.out.println("--------------------------------------------------");
			break;
		case 4:
			System.exit(-1);
		default:
			System.out.println("Invalid Choice...");
			System.out.println("--------------------------------------------------");
			break;
		}
		}		
	}
}
