package com.cg.banking.util;
import java.util.HashMap;
import com.cg.banking.beans.Account;
public class BankingDBUtil {
	public static HashMap<Long, Account> accounts = new HashMap<>();
	private static int ACCOUNT_ID_COUNTER = 10000;
	private static int TRANSACTION_ID_COUNTER = 1000;
	public static int getACCOUNT_ID_COUNTER() {
		return ++ACCOUNT_ID_COUNTER;
	}
	public static int getTRANSACTION_ID_COUNTER() {
		return ++TRANSACTION_ID_COUNTER;
	}
}
